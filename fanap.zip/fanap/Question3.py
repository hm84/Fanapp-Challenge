def Prime_number(x):  #This simple function checks whether the given number x is prime or not by checking its divisibility in the range 2 to x-1.
    key=True          #O(n)
    for i in range(2,x):
        if x%i==0 :
            key=False
            print("False")
            break
    
    if key!=False :
        print("True")

    
while (True):
    Prime_number(int(input("Please enter the desired number: ")))

# این عمل در حلقه بی نهایت قرار گرفته و تا وقتی کاربر در برنامه بماند مدام محاسبه انجام میدهد

'''
 (بدون حلقه) اگر قرار بودن عمل یکبار انجام شود:

Prime_number(int(input("Please enter the desired number: ")))

'''

