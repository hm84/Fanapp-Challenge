def Matrix():                               #Implementing a function with lists and two-dimensional lists (matrixes)
    matrix=[]                               #O(m*n)
    sum=0
    n=int(input("Enter the size of the square matrix: "))

    for i in range(n):           #O(m*n)
        row=input(f"row{i+1}:")           # نحوه درست وارد کردن هر بار ورودی: 12 5 6 یا 1 2 3
                                          #به تعداد ردیف ها با حلقه هر بار یک لیست گرفته میشود و در ماتریس 2 بعدی قرار میگیرد
        numbers=list(map(int, row.split()))

        matrix.append(numbers)
        sum+=matrix[i][i]

    print(sum)

    '''
    for r2 in matrix:
       print(r2)

    '''



Matrix()


'''
مثال مد نظر:

sum=0
matrix=[[9,8,7] ,[6,5,4] ,[3,2,1]]
for i in range(3):
    sum+=matrix[i][i]
print(sum)

'''