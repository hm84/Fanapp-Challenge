def Sort (my_p):                 #Combining functions, dictionaries, and lists
    value_dict=[]                #O(n + mlogm + m + m*n)
    my_dict={}
    my_dict[my_p[0]]=0
    i=0
    while(i<len(my_p)):                       #n
        if my_p[i]==' ':
            my_dict[my_p[i+1]]=i+1
        i+=1

    key_dict=sorted(my_dict.keys())            #mlogm

    for key in key_dict:                       #m
        value_dict.append(my_dict[key])

    n=len(value_dict)

    for i in range(n):                               #m*n
        andis=value_dict[i]
        while(andis<len(my_p) and my_p[andis]!=' '):
            print(my_p[andis],end='')
            andis+=1
        print(end=' ')

#این تابع در ابتدا حرف اول هر کلمه را پیدا میکند و با اندیس مورد نظر در یک دیکشنری قرار میدهد
#در مرحله بعد کلید های دیکشنری که همان حروف هستند طبق الفبا مرتب شده و در نهایت دوباره مقادیر یعنی اندیس ها در یک لیست ذخیره میشوند و طبق آن رشته مجدد چاپ میشود


user_p=input("Please enter the desired sentence: ")        #تابع برای هر ورودی مد نظر کاربر کار میکند
Sort(user_p)

#Sort("machine learning is fun")                            مثال مد نظر