def Repetition (numbers):          #A simple function using a collection with a list as input
    max=0                          #O(n**2)
    s_numbers=set(numbers)
    for i in s_numbers:
        count=0
        for j in numbers:
            if i==j :
                count+=1
        if count>max :
            max=i
    print(max)


user_list=input("Please enter your desired list: ")
number_list =[int(num.strip()) for num in user_list]
Repetition(number_list)


'''
مثال مد نظر :

def Repetition (numbers):          
    max=0                          
    s_numbers=set(numbers)
    for i in s_numbers:
        count=0
        for j in numbers:
            if i==j :
                count+=1
        if count>max :
            max=i
    print(max)

Repetition([4,3,3,3,2,2,1])

'''


'''
برای ایجاد یک راه حل با پیچدگی کمتر میتوان از راه حل زیر استفاده کرد: O(n)

from collections import Counter

numbers = [4, 3, 3, 3, 2, 2, 1]
count = Counter(numbers)
print(count)                             خروجی: Counter({3: 3, 2: 2, 4: 1, 1: 1})

'''