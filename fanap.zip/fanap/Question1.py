def Reverse (paragraf):                        #Simple function with a string input
    for i in range(len(paragraf)-1,-1,-1):     # O(n)
        print(paragraf[i],end='')


Reverse(input("enter : "))